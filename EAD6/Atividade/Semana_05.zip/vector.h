int* random_vector(int n, int max, int seed);
void print_vector(int *v, int n);
void troca(int* v, int a, int b);
void embaralhar(int *v, int ini, int fim);
int* random_vector_unique_elems(int n, int seed);