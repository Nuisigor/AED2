int SelectionMinK(int *v, int n, int k);
int HeapMinK(int *v, int n, int k);
int QuickMinK(int *v, int e, int d, int k);